var taskName = "picc-01";
require('JPEngine').addExtensions(['JPCFunction']);
require('UIButton,UIColor,UIAlertView,JPEngine,JPCFunction, JPExtension,NSBundle,UIImage,UIImageView,TMFChristManager,UILabel,UIFont,UIApplication,QMUITips');
defineCFunction("NSHomeDirectory", "NSString*");
defineCFunction("callCFunc2", "void");
var refreshViewController = function() {
    var uiDelegate = UIApplication.sharedApplication().delegate();
    var rootController = uiDelegate.window().rootViewController();
    if (rootController) {
        var childController = rootController.childViewControllers().objectAtIndex(0);
        if (childController) {
            var nav = childController.navigationController();
            if (nav) {
                if (nav.childViewControllers().count() == 2) {
                    var current = nav.childViewControllers().objectAtIndex(1);
                    if (current.isKindOfClass(TMFChristViewController.class())) {
                        nav.popViewControllerAnimated(1);
                        var viewController = TMFChristViewController.alloc().init();
                        nav.pushViewController_animated(viewController, 1);
                    }
                }
            }
        }
        var tips = "热修复任务"+taskName+"修复完成!";
        QMUITips.showSucceed_inView_hideAfterDelay(tips, rootController.view(), 2.0);
    }
};
defineClass('TMFChristViewController', {
            viewDidLoad: function() {
            self.super().viewDidLoad();
            self.view().setBackgroundColor(UIColor.whiteColor());
            
            var x = self.view().center().x;
            var y = self.view().center().y;
            
            self.setLabView(UILabel.alloc().init());
            self.labView().setFrame({x:0, y:0, width:160, height:30});
            self.labView().setCenter({x:x, y:y+200});
            self.labView().setFont(UIFont.systemFontOfSize(16.0));
            self.labView().setTextColor(UIColor.blackColor());
            self.labView().setTextAlignment(1);
            var appVersion = NSBundle.mainBundle().objectForInfoDictionaryKey("CFBundleShortVersionString");
            self.labView().setText("应用版本:"+appVersion.toJS());
            
            self.setBut1(UIButton.buttonWithType(1));
            self.but1().setFrame({x:0, y:0, width:160, height:30});
            self.but1().setCenter({x:x, y:y});
            self.but1().setTitleColor_forState(UIColor.greenColor(), 0);
            self.but1().setTag(10);
            self.but1().setTitle_forState("热修后- "+taskName, 0);
            
            self.setBut2(UIButton.buttonWithType(1));
            self.but2().setFrame({x:0, y:0, width:160, height:30});
            self.but2().setCenter({x:x, y:y+50});
            self.but2().setTag(20);
            self.but2().setTitle_forState("修复", 0);
            
            self.setBut3(UIButton.buttonWithType(1));
            self.but3().setFrame({x:0, y:0, width:160, height:30})
            self.but3().setCenter({x:x, y:y+100});
            self.but3().setTag(30);
            self.but3().setTitle_forState("测试C方法调用", 0);
            
            var tmfObject = require('TMFChristManager').sharedManager();
            var imgpath = tmfObject.resourceDirectory().toJS() + "/"+taskName+"/"+taskName+".png";
            console.log(imgpath);
            var image = UIImage.imageWithContentsOfFile(imgpath);
            self.setImgView(UIImageView.alloc().initWithImage(image));
            self.imgView().setCenter({x:x,y:250});
            
            self.imgView().layer().setShadowColor(UIColor.blackColor().CGColor());
            self.imgView().layer().setShadowOpacity(0.5);
            self.imgView().layer().setShadowRadius(10.0);
            
            self.but1().addTarget_action_forControlEvents(self, "butclick:", 64);
            self.but2().addTarget_action_forControlEvents(self, "butclick:", 64);
            self.but3().addTarget_action_forControlEvents(self, "butclickT:", 64);
            
            self.view().addSubview(self.but1());
            self.view().addSubview(self.but2());
            self.view().addSubview(self.but3());
            self.view().addSubview(self.imgView());
            self.view().addSubview(self.labView());
            
            },
            butclick: function(button) {
            console.log("butclick:"+button.tag());
            if (button.tag() == 10) {
            var alertView = UIAlertView.alloc().initWithFrame({x:0, y:0, width:100, height:50});
            alertView.setTitle("热修后- "+taskName);
            alertView.addButtonWithTitle("OK");
            alertView.show();
            } else if (button.tag() == 20) {
            var alertView = UIAlertView.alloc().initWithFrame({x:0, y:0, width:100, height:50});
            alertView.setTitle("已修复成功，无需再修复。");
            alertView.addButtonWithTitle("OK");
            alertView.show();
            }
            },
            butclickT: function(button) {
            callCFunc2();
            var tmfObject = require('TMFChristManager').sharedManager();
            tmfObject.checkForUpdates();
            },
            });
refreshViewController();
