var taskName = 'picc-01';//热修复任务名称
require('JPCleaner').cleanClass('TMFChristViewController');
require('UIApplication,QMUITips,TMFChristViewController');
var refreshViewController = function() {
    var uiDelegate = UIApplication.sharedApplication().delegate();
    var rootController = uiDelegate.window().rootViewController();
    if (rootController) {
        var childController = rootController.childViewControllers().objectAtIndex(0);
        if (childController) {
            var nav = childController.navigationController();
            if (nav) {
                if (nav.childViewControllers().count() == 2) {
                    var current = nav.childViewControllers().objectAtIndex(1);
                    if (current.isKindOfClass(TMFChristViewController.class())) {
                        nav.popViewControllerAnimated(1);
                        var viewController = TMFChristViewController.alloc().init();
                        nav.pushViewController_animated(viewController, 1);
                    }
                }
            }
        }
        var tips = "撤销热修复任务"+taskName+"撤销完成!";
        QMUITips.showSucceed_inView_hideAfterDelay(tips, rootController.view(), 2.0);
    }
};
refreshViewController();
